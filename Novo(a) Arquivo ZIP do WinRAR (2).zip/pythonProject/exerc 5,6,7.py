n1 =  int(input('Digite um número:  '))
result = 0
for c in range(1, n1 + 1):
    if n1 % c == 0:
        print(' \033[34m' , end='')
        result += 1
    else:
        print(' \033[31m' , end='')
    print(f'{c}', end='')
print(f'\n\33[mO número {n1} foi divisivel {result} vezes!')
if result == 2:
    print('E por isso é um número Primo!')
else:
    print('E por isso não é um número Primo!')