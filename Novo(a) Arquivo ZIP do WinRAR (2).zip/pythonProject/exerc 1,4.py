#Faça um programa que calcule o fatorial de um número inteiro fornecido pelo usuário. Ex.: 5!=5.4.3.2.1=120

numero = int(input('Informe um numero inteiro para efetuar o calculo de fatorial: '))
c = numero
fatorial = 1
print(f'Calculando {numero}! = ',end='')
while c > 0:
    print(f'{c}',end='')
    print(' x 'if c > 1 else ' = ', end='')
    fatorial *= c
    c -= 1
    print(f'{numero}! = {numero}',end='')
    decisao = True
    while decisao:
        numero = int(input('Informe um numero inteiro para efetuar o calculo de fatorial: '))
        c = numero
        print(f'Calculando {numero}! = ', end='')
        while c > 0 and c < 16:
            for fat in range(numero - 1, 0, - 1):
                c *= fat
        print(f'{c}')
        decisao_user = input('Deseja continuar? S ou N')
        if decisao_user.upper() == 'N':
            decisao = False
print(f'{fatorial}')