from pip._vendor.distlib.compat import raw_input

n_pessoas = int(raw_input("Quantidade de Pessoas? "))

maior = None

menor = None

soma_idades = 0

for i in range(n_pessoas):

    idade = int(raw_input("Idade? "))

    soma_idades += idade

    if maior == None and menor == None:
        maior, menor = idade, idade

    if idade > maior:
        maior = idade

    if idade < menor:
        menor = idade

media = soma_idades / n_pessoas

if 0 < media <= 25:

    turma = "Jovem"

elif 26 <= media <= 60:

    turma = "Adulta"

else:

    turma = "Idosa"

print(f'a maior parte das pessoas são {turma}, a média de idade é : {media} ')
