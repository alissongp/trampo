#Faça um programa que, dado um conjunto de N números, determine o menor valor, o maior valor e a soma dos valores.
import lista as lista

resp = 'Sim'
soma = quant = som = 0
while resp == 'Sim':
    num = int(input('Digite um número: '))
    soma += num
    quant += 1
    while not num in range(1, 1000):
        quant += num
        lista.append(num)

    resp =  str(input('Quer continuar?'))
som = soma + quant
print(f'Você digitou {quant} números e a soma deles é: {som}')